# Excercise files: 

Open the below files to continue with this excercise: 

- [check_images.py](../data/check_images.py)

